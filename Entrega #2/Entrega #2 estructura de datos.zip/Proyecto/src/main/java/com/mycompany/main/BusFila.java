package com.mycompany.main;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Clase BusFila que administra la flota de buses de forma dinámica y gestiona 
 * la cola de pasajeros (`Queue`) asignada a cada unidad (Módulos 1.1 y 1.3).
 */
public class BusFila {
    private int idBus;
    private String tipoBus; // "Preferencial", "Directo", "Normal"
    private Queue<Tiquete> colaPasajeros;

    public BusFila(int idBus, String tipoBus) {
        this.idBus = idBus;
        this.tipoBus = tipoBus;
        this.colaPasajeros = new LinkedList<>(); // Uso de colección estándar 
    }

    public void agregarPasajero(Tiquete tiquete) {
        colaPasajeros.add(tiquete);
    }

    public Tiquete atenderPasajero() {
        return colaPasajeros.poll();
    }

    public int getCantidadEnEspera() {
        return colaPasajeros.size();
    }

    public int getIdBus() { return idBus; }
    public String getTipoBus() { return tipoBus; }
    public Queue<Tiquete> getColaPasajeros() { return colaPasajeros; }
}