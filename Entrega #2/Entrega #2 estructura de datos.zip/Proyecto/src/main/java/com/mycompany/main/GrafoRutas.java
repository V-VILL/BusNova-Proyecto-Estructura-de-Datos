package com.mycompany.main;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Clase para gestionar el grafo ponderado dirigido de localidades, rutas 
 * y el cálculo de la ruta más corta (Módulo 1.4).
 */
public class GrafoRutas {
    private Map<String, Map<String, Integer>> grafo;

    public GrafoRutas() {
        grafo = new HashMap<>();
        // Definir localidades y pesos (km o tiempo) de las rutas
        agregarRuta("Terminal Central", "Heredia", 15);
        agregarRuta("Terminal Central", "San José", 25);
        agregarRuta("Heredia", "Alajuela", 20);
        agregarRuta("San José", "Cartago", 30);
        agregarRuta("Alajuela", "San José", 22);
    }

    public void agregarRuta(String origen, String destino, int pesoKm) {
        grafo.putIfAbsent(origen, new HashMap<>());
        grafo.get(origen).put(destino, pesoKm);
    }

    public String obtenerRepresentacionGrafo() {
        StringBuilder sb = new StringBuilder("--- GRAFO DE LOCALIDADES Y RUTAS ---\n");
        for (String origen : grafo.keySet()) {
            sb.append("Origen: ").append(origen).append(" -> \n");
            for (Map.Entry<String, Integer> destino : grafo.get(origen).entrySet()) {
                sb.append("   [Destino: ").append(destino.getKey())
                  .append(", Distancia: ").append(destino.getValue()).append(" km]\n");
            }
        }
        return sb.toString();
    }

    /**
     * Algoritmo de Dijkstra para encontrar la ruta más corta entre dos localidades.
     */
    public String encontrarRutaMasCorta(String inicio, String destino) {
        if (!grafo.containsKey(inicio) || !grafo.containsKey(destino)) {
            return "Una o ambas localidades no existen en el sistema.";
        }

        Map<String, Integer> distancias = new HashMap<>();
        Map<String, String> predecesores = new HashMap<>();
        PriorityQueue<NodoDistancia> colaPrioridad = new PriorityQueue<>((a, b) -> Integer.compare(a.distancia, b.distancia));

        for (String localidad : grafo.keySet()) {
            distancias.put(localidad, Integer.MAX_VALUE);
        }

        distancias.put(inicio, 0);
        colaPrioridad.add(new NodoDistancia(inicio, 0));

        while (!colaPrioridad.isEmpty()) {
            NodoDistancia actual = colaPrioridad.poll();

            if (actual.localidad.equals(destino)) {
                break;
            }

            if (actual.distancia > distancias.get(actual.localidad)) {
                continue;
            }

            Map<String, Integer> vecinos = grafo.get(actual.localidad);
            if (vecinos != null) {
                for (Map.Entry<String, Integer> vecino : vecinos.entrySet()) {
                    String siguienteLocalidad = vecino.getKey();
                    int nuevoPeso = vecino.getValue();
                    int nuevaDistancia = distancias.get(actual.localidad) + nuevoPeso;

                    if (nuevaDistancia < distancias.get(siguienteLocalidad)) {
                        distancias.put(siguienteLocalidad, nuevaDistancia);
                        predecesores.put(siguienteLocalidad, actual.localidad);
                        colaPrioridad.add(new NodoDistancia(siguienteLocalidad, nuevaDistancia));
                    }
                }
            }
        }

        if (distancias.get(destino) == Integer.MAX_VALUE) {
            return "No existe una ruta posible entre " + inicio + " y " + destino + ".";
        }

        // Reconstruir camino
        List<String> camino = new ArrayList<>();
        String paso = destino;
        while (paso != null) {
            camino.add(paso);
            paso = predecesores.get(paso);
        }
        Collections.reverse(camino);

        return "--- RUTA MÁS CORTA ---\n" +
               "Origen: " + inicio + "\n" +
               "Destino: " + destino + "\n" +
               "Distancia Total: " + distancias.get(destino) + " km\n" +
               "Camino: " + String.join(" -> ", camino);
    }

    // Clase auxiliar interna para la cola de prioridad de Dijkstra
    private static class NodoDistancia {
        String localidad;
        int distancia;

        public NodoDistancia(String localidad, int distancia) {
            this.localidad = localidad;
            this.distancia = distancia;
        }
    }

    public void guardarGrafoJSON() {
        try {
            StringBuilder json = new StringBuilder("{\n  \"localidades\": [\n");
            int i = 0;
            for (String origen : grafo.keySet()) {
                json.append("    {\n      \"origen\": \"").append(origen).append("\",\n      \"destinos\": [");
                int j = 0;
                Map<String, Integer> destinos = grafo.get(origen);
                for (Map.Entry<String, Integer> dest : destinos.entrySet()) {
                    json.append("{\"nombre\": \"").append(dest.getKey()).append("\", \"peso\": ").append(dest.getValue()).append("}");
                    if (j < destinos.size() - 1) json.append(", ");
                    j++;
                }
                json.append("]\n    }");
                if (i < grafo.size() - 1) json.append(",");
                json.append("\n");
                i++;
            }
            json.append("  ]\n}");

            FileWriter writer = new FileWriter("grafo.json");
            writer.write(json.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}