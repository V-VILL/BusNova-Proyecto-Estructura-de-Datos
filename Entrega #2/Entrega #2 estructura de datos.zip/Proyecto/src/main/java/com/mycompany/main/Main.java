package com.mycompany.main;

import javax.swing.JOptionPane;
import java.util.ArrayList;

/**
 * Clase principal Main que ejecuta el flujo de inicio de sesión, inicialización 
 * de la configuración y despliegue del menú interactivo completo de BusNovaTech.
 */
public class Main {

    public static void main(String[] args) {
        // 1. Módulo 1.0: Configuración y Persistencia inicial
        GestorJSON.inicializarOLeerConfiguracion();

        // Usuarios simulados para el acceso
        Usuario[] usuariosRegistrados = {
            new Usuario("admin", "1234"),
            new Usuario("operador", "abcd")
        };

        // 2. Login obligatorio
        boolean autenticado = false;
        int intentos = 3;

        while (intentos > 0 && !autenticado) {
            String user = JOptionPane.showInputDialog(null, "--- SISTEMA BUSNOVATECH ---\nIngrese su usuario:", "Login", JOptionPane.QUESTION_MESSAGE);
            if (user == null) System.exit(0);
            
            String pass = JOptionPane.showInputDialog(null, "Ingrese su contraseña:", "Login", JOptionPane.QUESTION_MESSAGE);
            
            for (Usuario u : usuariosRegistrados) {
                if (u.getUsername().equals(user) && u.autenticar(pass)) {
                    autenticado = true;
                    break;
                }
            }
            if (!autenticado) {
                intentos--;
                JOptionPane.showMessageDialog(null, "Credenciales incorrectas. Quedan " + intentos, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        if (!autenticado) {
            JOptionPane.showMessageDialog(null, "Acceso denegado.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }

        JOptionPane.showMessageDialog(null, "¡Bienvenido a BusNovaTech!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        // Inicializamos los buses (Ejemplo: Bus 1 Preferencial, Bus 2 Directo, Bus 3 Normal)
        ArrayList<BusFila> listaBuses = new ArrayList<>();
        listaBuses.add(new BusFila(1, "Preferencial"));
        listaBuses.add(new BusFila(2, "Directo"));
        listaBuses.add(new BusFila(3, "Normal"));

        // Instancia del Grafo de Rutas (Módulo 1.4)
        GrafoRutas grafoRutas = new GrafoRutas();
        grafoRutas.guardarGrafoJSON();

        // Menú Principal interactivo 
        boolean continuar = true;
        while (continuar) {
            String opcion = JOptionPane.showInputDialog(null, 
                "--- MENÚ PRINCIPAL ---\n" +
                "1. Crear Tiquete (Módulos 1.1 y 1.3)\n" +
                "2. Atender Pasajero (Módulo 1.2)\n" +
                "3. Mostrar Grafo y Localidades (Módulo 1.4)\n" +
                "4. Calcular Ruta Más Corta (Módulo 1.4)\n" +
                "5. Consultar Tipo de Cambio BCCR (Módulo 1.5)\n" +
                "6. Salir", 
                "BusNovaTech", JOptionPane.QUESTION_MESSAGE);

            if (opcion == null || opcion.equals("6")) {
                continuar = false;
                break;
            }

            switch (opcion) {
                case "1":
                    // Módulo 1.1 y 1.3: Creación de tiquete y asignación a colas
                    String nombre = JOptionPane.showInputDialog("Nombre del cliente:");
                    if (nombre == null) break;
                    
                    String id = JOptionPane.showInputDialog("Cédula / ID:");
                    if (id == null) break;
                    
                    String edadStr = JOptionPane.showInputDialog("Edad:");
                    if (edadStr == null) break;
                    int edad = Integer.parseInt(edadStr);
                    
                    String moneda = JOptionPane.showInputDialog("Moneda cuenta (dolares / colones):");
                    String servicio = JOptionPane.showInputDialog("Servicio (VIP, Regular, Carga, Ejecutivo):");
                    String tipoBus = JOptionPane.showInputDialog("Tipo Bus (P: Preferencial, D: Directo, N: Normal):");

                    // Solicitar el peso de la carga ÚNICAMENTE si el servicio es Carga
                    double peso = 0.0;
                    if (servicio != null && servicio.trim().equalsIgnoreCase("carga")) {
                        String pesoStr = JOptionPane.showInputDialog("Ingrese el peso de la carga (en lbs):");
                        try {
                            peso = Double.parseDouble(pesoStr);
                        } catch (NumberFormatException e) {
                            peso = 0.0;
                        }
                    }

                    Tiquete nuevoTiquete = new Tiquete(nombre, id, edad, moneda, servicio, tipoBus, peso);

                    // Asignación de colas según el tipo de bus (Módulo 1.3)
                    if (tipoBus.equalsIgnoreCase("P")) {
                        listaBuses.get(0).agregarPasajero(nuevoTiquete);
                        JOptionPane.showMessageDialog(null, "Tiquete asignado al Bus Preferencial (ID: 1)");
                    } else if (tipoBus.equalsIgnoreCase("D")) {
                        listaBuses.get(1).agregarPasajero(nuevoTiquete);
                        JOptionPane.showMessageDialog(null, "Tiquete asignado al Bus Directo (ID: 2)");
                    } else {
                        // Llenado inteligente de buses normales (Bus con menos personas en espera)
                        BusFila busSeleccionado = listaBuses.get(2);
                        for (BusFila b : listaBuses) {
                            if (b.getTipoBus().equalsIgnoreCase("Normal")) {
                                if (b.getCantidadEnEspera() < busSeleccionado.getCantidadEnEspera()) {
                                    busSeleccionado = b;
                                }
                            }
                        }
                        busSeleccionado.agregarPasajero(nuevoTiquete);
                        JOptionPane.showMessageDialog(null, "Tiquete asignado al Bus Normal (ID: " + busSeleccionado.getIdBus() + ")");
                    }
                    break;

                case "2":
                    // Módulo 1.2: Atención del tiquete por el inspector
                    String busIdStr = JOptionPane.showInputDialog("Ingrese el ID del bus a atender (Ej: 1, 2 o 3):");
                    if (busIdStr == null) break;
                    int idBusAtender = Integer.parseInt(busIdStr);
                    
                    BusFila busEncontrado = null;
                    for (BusFila b : listaBuses) {
                        if (b.getIdBus() == idBusAtender) {
                            busEncontrado = b;
                            break;
                        }
                    }

                    if (busEncontrado != null && !busEncontrado.getColaPasajeros().isEmpty()) {
                        Tiquete tAtender = busEncontrado.atenderPasajero();
                        double tipoCambioBCCR = ConsultaBCCR.obtenerTipoCambioDolarActual(); // Consulta real al Módulo 1.5
                        InspectorAtencion.procesarAtencion(tAtender, busEncontrado.getIdBus(), "Terminal Central", tipoCambioBCCR);
                    } else {
                        JOptionPane.showMessageDialog(null, "No hay pasajeros en la fila de este bus o el ID es inválido.", "Aviso", JOptionPane.WARNING_MESSAGE);
                    }
                    break;

                case "3":
                    // Módulo 1.4: Mostrar Grafo de Localidades
                    String representacionGrafo = grafoRutas.obtenerRepresentacionGrafo();
                    JOptionPane.showMessageDialog(null, representacionGrafo, "Servicios Complementarios (Grafo)", JOptionPane.INFORMATION_MESSAGE);
                    break;

                case "4":
                    // Módulo 1.4: Calcular la ruta más corta entre dos terminales elegidas
                    String origenInput = JOptionPane.showInputDialog("Ingrese la localidad de Origen (Ej: Terminal Central, Heredia, San José, Alajuela, Cartago):");
                    if (origenInput == null || origenInput.trim().isEmpty()) break;

                    String destinoInput = JOptionPane.showInputDialog("Ingrese la localidad de Destino:");
                    if (destinoInput == null || destinoInput.trim().isEmpty()) break;

                    String resultadoRuta = grafoRutas.encontrarRutaMasCorta(origenInput.trim(), destinoInput.trim());
                    JOptionPane.showMessageDialog(null, resultadoRuta, "Ruta Más Corta (Sin Costo)", JOptionPane.INFORMATION_MESSAGE);
                    break;

                case "5":
                    // Módulo 1.5: Consultar Tipo de Cambio BCCR en línea
                    double cambioActual = ConsultaBCCR.obtenerTipoCambioDolarActual();
                    JOptionPane.showMessageDialog(null, "El tipo de cambio actual del dólar (BCCR) es: ₡" + cambioActual, "Consulta BCCR", JOptionPane.INFORMATION_MESSAGE);
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida.");
                    break;
            }
        }
    }
}
