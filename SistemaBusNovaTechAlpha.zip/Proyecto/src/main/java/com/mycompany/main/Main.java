package com.mycompany.main;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // 1. Módulo 1.0: Configuración y Persistencia inicial
        GestorJSON.inicializarOLeerConfiguracion();

        // Usuarios simulados para el acceso
        Usuario[] usuariosRegistrados = {
            new Usuario("admin", "1234"),
            new Usuario("operador", "abcd")
        };

        // 2. Login obligatorio
        boolean autenticado = false;
        int intentos = 3;

        while (intentos > 0 && !autenticado) {
            String user = JOptionPane.showInputDialog(null, "--- SISTEMA BUSNOVATECH ---\nIngrese su usuario:", "Login", JOptionPane.QUESTION_MESSAGE);
            if (user == null) System.exit(0);
            
            String pass = JOptionPane.showInputDialog(null, "Ingrese su contraseña:", "Login", JOptionPane.QUESTION_MESSAGE);
            
            for (Usuario u : usuariosRegistrados) {
                if (u.getUsername().equals(user) && u.autenticar(pass)) {
                    autenticado = true;
                    break;
                }
            }
            if (!autenticado) {
                intentos--;
                JOptionPane.showMessageDialog(null, "Credenciales incorrectas. Quedan " + intentos, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        if (!autenticado) {
            JOptionPane.showMessageDialog(null, "Acceso denegado.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }

        JOptionPane.showMessageDialog(null, "¡Bienvenido a BusNovaTech!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        // Inicializamos los buses (Ejemplo: Bus 1 Preferencial, Bus 2 Directo, Bus 3 Normal)
        ArrayList<BusFila> listaBuses = new ArrayList<>();
        listaBuses.add(new BusFila(1, "Preferencial"));
        listaBuses.add(new BusFila(2, "Directo"));
        listaBuses.add(new BusFila(3, "Normal"));

        // Menú Principal interactivo para probar los módulos
        boolean continuar = true;
        while (continuar) {
            String opcion = JOptionPane.showInputDialog(null, 
                "--- MENÚ PRINCIPAL ---\n" +
                "1. Crear Tiquete (Módulos 1.1 y 1.3)\n" +
                "2. Atender Pasajero (Módulo 1.2)\n" +
                "3. Salir", 
                "BusNovaTech", JOptionPane.QUESTION_MESSAGE);

            if (opcion == null || opcion.equals("3")) {
                continuar = false;
                break;
            }

            switch (opcion) {
                case "1":
                    // Módulo 1.1 y 1.3: Creación de tiquete y asignación a colas
                    String nombre = JOptionPane.showInputDialog("Nombre del cliente:");
                    String id = JOptionPane.showInputDialog("Cédula / ID:");
                    int edad = Integer.parseInt(JOptionPane.showInputDialog("Edad:"));
                    String moneda = JOptionPane.showInputDialog("Moneda cuenta (dolares / colones):");
                    String servicio = JOptionPane.showInputDialog("Servicio (VIP, Regular, Carga, Ejecutivo):");
                    String tipoBus = JOptionPane.showInputDialog("Tipo Bus (P: Preferencial, D: Directo, N: Normal):");
                    double peso = Double.parseDouble(JOptionPane.showInputDialog("Peso de carga (en lbs):"));

                    Tiquete nuevoTiquete = new Tiquete(nombre, id, edad, moneda, servicio, tipoBus, peso);

                    // Asignación de colas según el tipo de bus
                    if (tipoBus.equalsIgnoreCase("P")) {
                        listaBuses.get(0).agregarPasajero(nuevoTiquete);
                        JOptionPane.showMessageDialog(null, "Tiquete asignado al Bus Preferencial (ID: 1)");
                    } else if (tipoBus.equalsIgnoreCase("D")) {
                        listaBuses.get(1).agregarPasajero(nuevoTiquete);
                        JOptionPane.showMessageDialog(null, "Tiquete asignado al Bus Directo (ID: 2)");
                    } else {
                        // Llenado inteligente de buses normales (Bus con menos personas en fila - Módulo 1.3)
                        BusFila busSeleccionado = listaBuses.get(2); // Asumimos el normal
                        for (BusFila b : listaBuses) {
                            if (b.getTipoBus().equalsIgnoreCase("Normal")) {
                                if (b.getCantidadEnEspera() < busSeleccionado.getCantidadEnEspera()) {
                                    busSeleccionado = b;
                                }
                            }
                        }
                        busSeleccionado.agregarPasajero(nuevoTiquete);
                        JOptionPane.showMessageDialog(null, "Tiquete asignado al Bus Normal (ID: " + busSeleccionado.getIdBus() + ")");
                    }
                    break;

                case "2":
                    // Módulo 1.2: Atención del tiquete por el inspector
                    String busIdStr = JOptionPane.showInputDialog("Ingrese el ID del bus a atender (Ej: 1, 2 o 3):");
                    int idBusAtender = Integer.parseInt(busIdStr);
                    
                    BusFila busEncontrado = null;
                    for (BusFila b : listaBuses) {
                        if (b.getIdBus() == idBusAtender) {
                            busEncontrado = b;
                            break;
                        }
                    }

                    if (busEncontrado != null && !busEncontrado.getColaPasajeros().isEmpty()) {
                        Tiquete tAtender = busEncontrado.atenderPasajero();
                        // Simulamos un tipo de cambio fijo por ahora (Ej: 520 colones por dólar)
                        double tipoCambioBCCR = 520.0; 
                        InspectorAtencion.procesarAtencion(tAtender, busEncontrado.getIdBus(), "Terminal Central", tipoCambioBCCR);
                    } else {
                        JOptionPane.showMessageDialog(null, "No hay pasajeros en la fila de este bus o el ID es inválido.", "Aviso", JOptionPane.WARNING_MESSAGE);
                    }
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida.");
                    break;
            }
        }
    }
}
