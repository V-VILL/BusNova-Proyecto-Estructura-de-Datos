package com.mycompany.main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.swing.JOptionPane;

/**
 * Clase GestorJSON encargada de administrar la persistencia y configuración inicial
 * del sistema BusNovaTech a través del archivo config.json (Módulo 1.0).
 */
public class GestorJSON {
    
    private static final String CONFIG_FILE = "config.json";

    public static void inicializarOLeerConfiguracion() {
        File archivo = new File(CONFIG_FILE);
        if (!archivo.exists()) {
            crearConfiguracionInteractiva();
        } else {
            try {
                String contenido = new String(Files.readAllBytes(Paths.get(CONFIG_FILE)));
                JOptionPane.showMessageDialog(null, 
                    "Configuración cargada exitosamente desde config.json:\n\n" + contenido, 
                    "Sistema Restaurado", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al leer config.json.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void guardarConfiguracion(String terminal, int totalBuses, String[][] credencialesUsuarios) {
        try {
            StringBuilder sbUsuarios = new StringBuilder();
            for (int i = 0; i < credencialesUsuarios.length; i++) {
                sbUsuarios.append("    {\n");
                sbUsuarios.append("      \"username\": \"").append(credencialesUsuarios[i][0]).append("\",\n");
                sbUsuarios.append("      \"password\": \"").append(credencialesUsuarios[i][1]).append("\"\n");
                sbUsuarios.append("    }");
                if (i < credencialesUsuarios.length - 1) sbUsuarios.append(",\n");
                else sbUsuarios.append("\n");
            }

            int busesNormales = totalBuses - 2;

            String jsonConfig = "{\n" +
                    "  \"nombreTerminal\": \"" + terminal + "\",\n" +
                    "  \"totalBuses\": " + totalBuses + ",\n" +
                    "  \"flotaBuses\": {\n" +
                    "    \"busPreferencial\": 1,\n" +
                    "    \"busDirecto\": 1,\n" +
                    "    \"busesNormales\": " + busesNormales + "\n" +
                    "  },\n" +
                    "  \"usuarios\": [\n" + sbUsuarios.toString() + "\n  ]\n" +
                    "}";

            FileWriter writer = new FileWriter(CONFIG_FILE);
            writer.write(jsonConfig);
            writer.close();

            JOptionPane.showMessageDialog(null, "Configuración guardada en config.json", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar config.json", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void crearConfiguracionInteractiva() {
        JOptionPane.showMessageDialog(null, "Primera ejecución: Ingrese la configuración inicial.", "Configuración", JOptionPane.WARNING_MESSAGE);
        
        String nombreTerminal = JOptionPane.showInputDialog(null, "Ingrese el nombre de la terminal:");
        if (nombreTerminal == null || nombreTerminal.trim().isEmpty()) {
            nombreTerminal = "Terminal Central";
        }

        String cantidadBusesStr = JOptionPane.showInputDialog(null, "Ingrese la cantidad total de buses (Mínimo 3):");
        int totalBuses = 3;
        try {
            totalBuses = Integer.parseInt(cantidadBusesStr);
            if (totalBuses < 3) totalBuses = 3;
        } catch (NumberFormatException e) {
            totalBuses = 3;
        }

        String[][] usuariosGrupo = new String[2][2];
        usuariosGrupo[0][0] = "admin"; usuariosGrupo[0][1] = "1234";
        usuariosGrupo[1][0] = "operador"; usuariosGrupo[1][1] = "abcd";

        guardarConfiguracion(nombreTerminal, totalBuses, usuariosGrupo);
    }
}
