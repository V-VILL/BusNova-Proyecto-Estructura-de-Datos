package com.mycompany.main;

public class Usuario {
    //
    private String username;
    private String password;

    public Usuario(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public boolean autenticar(String pass) {
        return this.password.equals(pass);
    }

    public String getUsername() {
        return username;
    }
}
