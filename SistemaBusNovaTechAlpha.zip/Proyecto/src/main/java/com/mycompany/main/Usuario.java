package com.mycompany.main;

/**
 * Clase Usuario para gestionar la autenticación de los operadores del sistema 
 * a partir de las credenciales obtenidas desde la base de datos local (config.json).
 */
public class Usuario {
    private String username;
    private String password;

    public Usuario(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /**
     * Valida si la contraseña ingresada coincide con la del usuario.
     */
    public boolean autenticar(String pass) {
        return this.password.equals(pass);
    }

    public String getUsername() {
        return username;
    }
}
