package com.mycompany.main;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

public class InspectorAtencion {

    public static void procesarAtencion(Tiquete tiquete, int idBus, String nombreTerminal, double tipoCambio) {
        double costo = tiquete.calcularCostoServicio(tipoCambio);
        
        int opcion = JOptionPane.showConfirmDialog(null, 
            "Cliente: " + tiquete.getNombreCliente() + "\nServicio: " + tiquete.getTipoServicio() + 
            "\nTotal a pagar: " + costo + "\n¿Desea realizar el pago y abordar?", 
            "Atención de Inspector", 
            JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
            String horaActual = LocalTime.now().format(dtf);
            
            tiquete.setHoraAbordaje(horaActual); 
            guardarAtendidoEnJSON(tiquete, nombreTerminal, idBus, horaActual);
            
            JOptionPane.showMessageDialog(null, "¡Cliente abordó con éxito!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "El cliente se negó a pagar. Sale de la fila.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private static void guardarAtendidoEnJSON(Tiquete tiquete, String terminal, int idBus, String horaAtencion) {
        try {
            String registro = "{\n" +
                    "  \"terminal\": \"" + terminal + "\",\n" +
                    "  \"idBus\": " + idBus + ",\n" +
                    "  \"horaAtencion\": \"" + horaAtencion + "\",\n" +
                    "  \"tiquete\": " + tiquete.toJSON() + "\n" +
                    "}\n";

            FileWriter writer = new FileWriter("atendidos.json", true);
            writer.write(registro);
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar en atendidos.json", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}