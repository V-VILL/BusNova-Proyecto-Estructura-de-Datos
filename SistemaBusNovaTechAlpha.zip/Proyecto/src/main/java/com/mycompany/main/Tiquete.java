package com.mycompany.main;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Clase Tiquete que modela los datos del pasajero, hora de compra, hora de abordaje,
 * tipos de servicio y el cálculo de costos (Módulos 1.1 y 1.2).
 */
public class Tiquete {
    private String nombreCliente;
    private String idCliente;
    private int edad;
    private String monedaCuenta; // "dolares" o "colones"
    private String horaCompra;
    private String horaAbordaje; // Por defecto "-1" hasta que sea atendido
    private String tipoServicio; // "VIP", "Regular", "Carga", "Ejecutivo"
    private String tipoBus;     // "P" (Preferencial), "D" (Directo), "N" (Normal)
    private double pesoCarga;

    public Tiquete(String nombreCliente, String idCliente, int edad, String monedaCuenta, String tipoServicio, String tipoBus, double pesoCarga) {
        this.nombreCliente = nombreCliente;
        this.idCliente = idCliente;
        this.edad = edad;
        this.monedaCuenta = monedaCuenta;
        
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
        this.horaCompra = LocalTime.now().format(dtf);
        
        this.horaAbordaje = "-1"; // Inicializado en -1 según requerimiento
        this.tipoServicio = tipoServicio;
        this.tipoBus = tipoBus;
        this.pesoCarga = pesoCarga;
    }

    public String getNombreCliente() { return nombreCliente; }
    public String getIdCliente() { return idCliente; }
    public String getTipoBus() { return tipoBus; }
    public String getTipoServicio() { return tipoServicio; }
    public void setHoraAbordaje(String horaAbordaje) { this.horaAbordaje = horaAbordaje; }

    /**
     * Calcula el costo del servicio aplicando las reglas de cobro del Módulo 1.2:
     * - VIP: $100 adicionales
     * - Regular: $20 base
     * - Carga: $20 + $10 por cada lb
     * - Ejecutivo: $1000 adicionales
     */
    public double calcularCostoServicio(double tipoCambio) {
        double costoBaseColones;
        
        switch (tipoServicio.toLowerCase()) {
            case "vip":
                costoBaseColones = (20 + 100) * tipoCambio;
                break;
            case "regular":
                costoBaseColones = 20 * tipoCambio;
                break;
            case "carga":
                costoBaseColones = (20 + (pesoCarga * 10)) * tipoCambio;
                break;
            case "ejecutivo":
                costoBaseColones = (20 + 1000) * tipoCambio;
                break;
            default:
                costoBaseColones = 20 * tipoCambio;
                break;
        }
        
        if (monedaCuenta.equalsIgnoreCase("dolares")) {
            return costoBaseColones / tipoCambio;
        }
        return costoBaseColones;
    }

    /**
     * Convierte los atributos del tiquete a una estructura de texto en formato JSON.
     */
    public String toJSON() {
        return "{\n" +
                "  \"nombre\": \"" + nombreCliente + "\",\n" +
                "  \"id\": \"" + idCliente + "\",\n" +
                "  \"edad\": " + edad + ",\n" +
                "  \"monedaCuenta\": \"" + monedaCuenta + "\",\n" +
                "  \"horaCompra\": \"" + horaCompra + "\",\n" +
                "  \"horaAbordaje\": \"" + horaAbordaje + "\",\n" +
                "  \"servicio\": \"" + tipoServicio + "\",\n" +
                "  \"tipoBus\": \"" + tipoBus + "\",\n" +
                "  \"pesoCarga\": " + pesoCarga + "\n" +
                "}";
    }
}