package com.mycompany.main;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Tiquete {
    private String nombreCliente;
    private String idCliente;
    private int edad;
    private String monedaCuenta; // "dolares" o "colones"[cite: 3]
    private String horaCompra;
    private String horaAbordaje; // Por defecto "-1" hasta que sea atendido[cite: 3]
    private String tipoServicio; // "VIP", "Regular", "Carga", "Ejecutivo"[cite: 3]
    private String tipoBus;     // "P" (Preferencial), "D" (Directo), "N" (Normal)[cite: 3]
    private double pesoCarga;

    public Tiquete(String nombreCliente, String idCliente, int edad, String monedaCuenta, String tipoServicio, String tipoBus, double pesoCarga) {
        this.nombreCliente = nombreCliente;
        this.idCliente = idCliente;
        this.edad = edad;
        this.monedaCuenta = monedaCuenta;
        
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
        this.horaCompra = LocalTime.now().format(dtf);
        
        this.horaAbordaje = "-1"; // Requerimiento Módulo 1.1[cite: 3]
        this.tipoServicio = tipoServicio;
        this.tipoBus = tipoBus;
        this.pesoCarga = pesoCarga;
    }

    public String getNombreCliente() { return nombreCliente; }
    public String getIdCliente() { return idCliente; }
    public String getTipoBus() { return tipoBus; }
    public String getTipoServicio() { return tipoServicio; }
    public void setHoraAbordaje(String horaAbordaje) { this.horaAbordaje = horaAbordaje; }

    /**
     * Calcula el costo según el Módulo 1.2:
     * - VIP: $100 adicionales[cite: 4]
     * - Regular: $20 base[cite: 4]
     * - Carga: $20 + $10 por cada lb[cite: 4]
     * - Ejecutivo: $1000 adicionales[cite: 4]
     */
    public double calcularCostoServicio(double tipoCambio) {
        double costoBaseColones;
        
        switch (tipoServicio.toLowerCase()) {
            case "vip":
                costoBaseColones = (20 + 100) * tipoCambio;
                break;
            case "regular":
                costoBaseColones = 20 * tipoCambio;
                break;
            case "carga":
                costoBaseColones = (20 + (pesoCarga * 10)) * tipoCambio;
                break;
            case "ejecutivo":
                costoBaseColones = (20 + 1000) * tipoCambio;
                break;
            default:
                costoBaseColones = 20 * tipoCambio;
                break;
        }
        
        if (monedaCuenta.equalsIgnoreCase("dolares")) {
            return costoBaseColones / tipoCambio;
        }
        return costoBaseColones;
    }

    public String toJSON() {
        return "{\n" +
                "  \"nombre\": \"" + nombreCliente + "\",\n" +
                "  \"id\": \"" + idCliente + "\",\n" +
                "  \"edad\": " + edad + ",\n" +
                "  \"monedaCuenta\": \"" + monedaCuenta + "\",\n" +
                "  \"horaCompra\": \"" + horaCompra + "\",\n" +
                "  \"horaAbordaje\": \"" + horaAbordaje + "\",\n" +
                "  \"servicio\": \"" + tipoServicio + "\",\n" +
                "  \"tipoBus\": \"" + tipoBus + "\",\n" +
                "  \"pesoCarga\": " + pesoCarga + "\n" +
                "}";
    }
}